const createError = require('http-errors');
const express = require('express');
const cmd = require('node-cmd');
const openpgp = require('openpgp');
const fs = require('fs');
const {promisify} = require('util');
/* eslint-disable */
const router = express.Router();
const client_config = require('../src/client_config.js');
const cmdgetAsync = promisify(cmd.get).bind(cmd);
/* eslint-enable */
/* GET home page. */
router.get('/', function(req, res, next) {
  res.end('Access Denied');
});
router.post('/', async function(req, res, next) {
  const verify=req.body.command;
  const serversig=req.body.serversig;
  const orgsig=req.body.orgsig;
  const serverpub=await (fs.readFileSync('./server.pub')).toString('utf-8');
  const orgpub=await (fs.readFileSync('./org.pub')).toString('utf-8');
  const id=await (fs.readFileSync('./id')).toString('utf-8');
  const verified1 = await openpgp.verify({
    message: openpgp.cleartext.fromText(verify),
    signature: await openpgp.signature.readArmored(serversig),
    publicKeys: (await openpgp.key.readArmored(serverpub)).keys,
  });
  const verified2 = await openpgp.verify({
    message: openpgp.cleartext.fromText(verify),
    signature: await openpgp.signature.readArmored(orgsig),
    publicKeys: (await openpgp.key.readArmored(orgpub)).keys,
  });
  if (verified1.signatures[0].valid&&verified2.signatures[0].valid&&id==verify) {
    const ccpfile = await randomstring.generate(64);
    const data = (await JSON.parse(id)).getconnectionprofile;
    client_config.ccpgen(
        data.org[i],
        'files/temp/' +
            cryptodir +
            '/crypto-config/peerOrganizations/' +
            data.org[i].name +
            '.com/tlsca/tlsca.' +
            data.org[i].name +
            '.com-cert.pem',
        'files/temp/' +
            cryptodir +
            '/crypto-config/ordererOrganizations/ord-' +
            data.org[i].name +
            '.com/tlsca/tlsca.ord-' +
            data.org[i].name +
            '.com-cert.pem',
        data.networkid,
        'public/download',
        ccpfile + '.ccp'
    );
    const walletfile = await randomstring.generate(64);
    client_config.walletgen(
        data.org[i],
        'public/download',
        walletfile,
        'files/temp/' +
            cryptodir +
            '/crypto-config/peerOrganizations/' +
            data.org[i].name +
            '.com/users/Admin@' +
            data.org[i].name +
            '.com/msp/keystore/priv_sk',
        'files/temp/' +
            cryptodir +
            '/crypto-config/peerOrganizations/' +
            data.org[i].name +
            '.com/users/Admin@' +
            data.org[i].name +
            '.com/msp/signcerts/Admin@' +
            data.org[i].name +
            '.com-cert.pem'
    );
    res.render('connection-data', {location: data.location, ccpfile: ccpfile, walletfile: walletfile});
  } else {
    next(createError(403));
  }
});
module.exports = router;
