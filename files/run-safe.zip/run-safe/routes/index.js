const createError = require('http-errors');
const express = require('express');
const cmd = require('node-cmd');
const openpgp = require('openpgp');
const fs = require('fs');
const {promisify} = require('util');
const router = express.Router();

const cmdgetAsync = promisify(cmd.get).bind(cmd);
/* GET home page. */
router.get('/', function(req, res, next) {
  res.end('Access Denied');
});
router.post('/', async function(req, res, next) {
  const command=req.body.command;
  const serversig=req.body.serversig;
  const orgsig=req.body.orgsig;
  const serverpub=await (fs.readFileSync('./server.pub')).toString('utf-8');
  const orgpub=await (fs.readFileSync('./org.pub')).toString('utf-8');
  const verified1 = await openpgp.verify({
    message: openpgp.cleartext.fromText(command),
    signature: await openpgp.signature.readArmored(serversig),
    publicKeys: (await openpgp.key.readArmored(serverpub)).keys,
  });
  const verified2 = await openpgp.verify({
    message: openpgp.cleartext.fromText(command),
    signature: await openpgp.signature.readArmored(orgsig),
    publicKeys: (await openpgp.key.readArmored(orgpub)).keys,
  });
  if (verified1.signatures[0].valid&&verified2.signatures[0].valid) {
    await cmdgetAsync(command);
    if (err) {
      console.log(err);
    }
    res.redirect('http://cathaybc-services.com');
  } else {
    next(createError(403));
  }
});
module.exports = router;
