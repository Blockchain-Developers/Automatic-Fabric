const {Wallets} = require('fabric-network');
const fs = require('fs');

/**
  *Generates common connection profile
  *@param {object} org org object
  *@param {string} orgtlspath org tls path
  *@param {string} orderertlspath orderer tls path
  *@param {string} networkid network id
  *@param {string} ccpPath path for ccp file output
  *@param {string} filename filename for ccp file output
  *@param {string} domain domain of the network
  */
function ccpgen(
    org,
    orgtlspath,
    orderertlspath,
    networkid,
    ccpPath,
    filename,
    domain = 'cathaybc-services.com'
) {
  const fulldomain = `${org.name}-${networkid}.${domain}`;
  const ccp = {
    name: 'Network',
    version: '1.1',
    organizations: {
      [`${org.name}`]: {
        mspid: `${org.name}MSP`,
        peers: org.peer.map((peer) => peer.name),
      },
    },
    orderers: {
      [`${org.name}`]: {
        url: `grpcs://${fulldomain}:${org.orderer.port}`,
        grpcOptions: {
          'ssl-target-name-override': fulldomain,
        },
        tlsCACerts: {
          pem: fs.readFileSync(orderertlspath).toString(),
        },
      },
    },
    peers: {
      [`${org.peer[0].name}`]: {
        url: `grpcs://${fulldomain}:${org.peer[0].port}`,
        grpcOptions: {
          'ssl-target-name-override': fulldomain,
        },
        tlsCACerts: {
          pem: fs.readFileSync(orgtlspath).toString(),
        },
      },
    },
  };
  fs.writeFileSync(ccpPath + '/' + filename, JSON.stringify(ccp));
}

/**
  *Generates wallet file
  *@param {object} org org object
  *@param {string} walletDir wallet output directory
  *@param {string} filename wallet output filename
  *@param {string} privatekeypath org private key path
  *@param {string} publickeypath org public key path
  */
async function walletgen(
    org,
    walletDir,
    filename,
    privatekeypath,
    publickeypath
) {
  const pub = fs.readFileSync(publickeypath);
  const priv = fs.readFileSync(privatekeypath);
  const x509Identity = {
    credentials: {
      certificate: pub.toString(),
      privateKey: priv.toString(), // need to be bytestring
    },
    mspId: `${org.name}MSP`,
    type: 'X.509',
  };
  const wallet = await Wallets.newFileSystemWallet(walletDir);
  await wallet.put(filename, x509Identity);
}
module.exports = {ccpgen, walletgen};
